#include "runtime.h"

int main()
{
  print_int_nl(1);
}
