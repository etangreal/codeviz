#include "runtime.h"

int main()
{
  int x = input();
  print_int_nl(x);
}
