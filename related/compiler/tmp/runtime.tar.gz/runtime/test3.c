#include "runtime.h"

int main()
{
  pyobj x = input_int();
  print_any(x);
}
