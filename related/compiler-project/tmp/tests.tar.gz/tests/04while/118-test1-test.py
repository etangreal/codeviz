x = 0
while x < 3:
	if (x > 0):
		m = 10
                while m < 20:
			if (m > 15):
				print m
			else:
				p = 1
                                while p < 5:
					print p*1000
                                        p = p + 1
                        m = m + 1
        x = x + 1
