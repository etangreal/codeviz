x = 1
while x < 3:
	m = 1
        while m < 11:
		g = m*x
		if (g > 6):
			print g
                m = m + 1
        x = x + 1
