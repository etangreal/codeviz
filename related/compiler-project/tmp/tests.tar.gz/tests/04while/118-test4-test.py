x = 1
while x < 100:
	if (x <= 50):
		print x*2 
        x = x + 1
