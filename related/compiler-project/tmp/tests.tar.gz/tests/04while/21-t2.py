x = 1
print x
y = 2
print y
while x < 10:
    y = x * 2
    print y
    x += 1
print y
