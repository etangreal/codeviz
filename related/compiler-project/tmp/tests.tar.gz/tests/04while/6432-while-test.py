x=0
while(x<5):
	print x
	x= x+1

while(False):
	print 'error'

