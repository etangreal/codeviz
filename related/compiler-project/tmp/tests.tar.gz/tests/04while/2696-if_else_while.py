c = input()
if(c >= 0):
	print c
	while c != 0:
		c = c - 1
	print c
else:
	print c
	print c-c
