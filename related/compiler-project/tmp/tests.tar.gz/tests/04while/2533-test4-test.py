#!/usr/bin/env python2.7

x = True
y = False
z = 0

if(x):
    print(1)
if(y):
    print(2)
while(z<=2):
    print(z)
    z = z + 1

