# Testing while loop
i=0
x=input()
while i<100:
    i=i+1
    x=x+5
print x
