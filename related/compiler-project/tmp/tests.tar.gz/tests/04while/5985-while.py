## Josafat Piraquive
## Simon Maurer
##
## while testcases
##

a = input()
i = input()
inc = input()
while i < a:
    print i
    i += inc
print i

i = input()
while i <= a:
    print i
    i += inc
print i
