x = 0
while x < 100:
	if (x <= 20):
		print x
	elif(x>= 90):
		 print x*10
        x = x + 1
