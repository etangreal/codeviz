#28


x = "1"
print x