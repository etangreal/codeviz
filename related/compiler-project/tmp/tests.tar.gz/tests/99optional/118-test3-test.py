for x in range(0,100):
	if (x <= 20):
		print x
	elif(x>= 90):
		 print x*10
