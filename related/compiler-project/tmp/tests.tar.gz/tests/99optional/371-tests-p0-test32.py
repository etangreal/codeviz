#32


x = "1 + f"
print x