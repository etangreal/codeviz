## Josafat Piraquive
## Simon Maurer
##
## boolean testcases
##

print True
print False
print True + input()
print True - input()
print False - True
print False - False + True + False - True
print True/True
print True*False
print True*True

True = input()
print True

## In Python, false can also be written as 0 and true as 1.
