for x in range(1, 100):
	if (x <= 50):
		print x*2 
