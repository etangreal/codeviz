def func(a,b):
    print a
    print b
func(4,5)
