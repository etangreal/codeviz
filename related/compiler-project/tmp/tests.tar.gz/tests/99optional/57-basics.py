n = 1
y = n + 1
x = input()
print x
bt1 = True
bf1 = False
andt1=bt1 and bt1
print bt1 and bt1
print bt1 and bf1
print bf1 or bt1
not bt1
print n==y
print n!=y
print n<=y
print n>=y
print n>y
print n<y

if bt1:
    print input()
elif andt1:
    print 0
else:
    pring 0

if bf1:
    print 0
elif andt1:
    print input()
else:
    pring 0

if bt1:
    print 0
elif andt1:
    print 0
else:
    print input()

x = - input()
print x + input()

n0 = 0
n1 = 1
n0 - n1
r0 = n1 - n1
-n1
print r0
print -n1
n1 * 2
n2=2
print n1 * n2
n2/n1
n4 = 4
print 4/n2
print n4/n2
n1/0
~3
n00=~2+3
bn0 = n00 == n0
print bn0
nn5=~n4
print ~nn5