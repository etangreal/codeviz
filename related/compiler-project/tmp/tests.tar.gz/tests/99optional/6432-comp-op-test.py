a=input()
b=input()
c=input()
d=input()
print a<b
print a>b
print a<c
print a>c
print a>=b
print a<=b
print a>=c
print a<=c
print a==b
print a!=b
print a==c
print a!=c
print a==True
print a>True
print a<True
print a>=True
print a<=True
print a==False
print a>False
print a<False
print a>=False
print a<=False
print b==True
print b>True
print b<True
print b>=True
print b<=True
print b==False
print b>False
print b<False
print b>=False
print b<=False
print d==True
print d>True
print d<True
print d>=True
print d<=True
print d==False
print d>False
print d<False
print d>=False
print d<=False
print True==1
print True!=1
print False==0
print False!=0
print False==True
print True!=False
s1=input()
s2=input()
s3=input()
print s1==s2
print s1==s3
print s1<s2
print s1<s3
print s1>s3
print s1!=s3
print 1!=False
print 0!=True