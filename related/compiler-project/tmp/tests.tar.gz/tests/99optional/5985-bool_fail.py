## Josafat Piraquive
## Simon Maurer
##
## boolean testcases that fail with error because of float values
##

print True + 1.1 + 12 + False * True
print True * 0.256
