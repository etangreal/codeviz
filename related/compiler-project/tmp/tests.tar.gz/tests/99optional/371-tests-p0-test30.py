#30


x = "1" 
x=x+10
print x