for x in range(0,3):
	if (x > 0):
		for m in range(10, 20):
			if (m > 15):
				print m
			else:
				for p in range(1,5):
					print p*1000
