def add(self,x,y):
	return x+y

print add(3,2)
print add('a','b')
print add(-3,1)
print add('a',3)

def printFunction():
	print "Hello, I'm a function!!!"

printFunction()

def printInputArg():
	print input()

printInputArg()
printInputArg()
printInputArg()
printInputArg()