def func():
    print 999
func()
