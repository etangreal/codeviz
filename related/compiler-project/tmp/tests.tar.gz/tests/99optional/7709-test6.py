#variable overloading
x="MGF"
x=True
x=10
print x
