#31


x = "1 + x"
print x