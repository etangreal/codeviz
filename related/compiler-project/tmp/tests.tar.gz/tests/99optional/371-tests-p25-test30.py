#30
#while statements | Test succeeds 

while(True):
	print 4
	break