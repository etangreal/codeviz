for x in range(1,3):
	for m in range(1,11):
		g = m*x
		if (g > 6):
			print g
