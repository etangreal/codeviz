def func1():
    return 999
def func2(a,b,c):
    print a
    print b
    print c
    print func1()
func2(1,2,3)
