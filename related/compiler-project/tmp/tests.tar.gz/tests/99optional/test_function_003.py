def func():
    return 999
print func()
