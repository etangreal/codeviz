def add(x,y):
	return x+y

print add(3,2)
print add(-3,1)

def printFunction():
	print 999

printFunction()

def printInputArg():
	print input()

printInputArg()
printInputArg()
printInputArg()
printInputArg()
