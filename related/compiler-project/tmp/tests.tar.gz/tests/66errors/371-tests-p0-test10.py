#10


x = - 99
y = 55
print x + y