#7


print 1
x = - 1
print x