#20


a = 1
b = 2
c = 3
e = 4
f = 5
g = 6
x = a + b
print x
q = x + c
print q
a = e + f + q
print a