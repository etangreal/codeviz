#17


x = 2 * 3
print x