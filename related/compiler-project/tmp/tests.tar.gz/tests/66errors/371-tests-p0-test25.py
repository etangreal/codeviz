#25


t1 = 3
print 1
t2 = 1
x = t2 + t1
print x