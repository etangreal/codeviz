a = 3
while a=3:
