#15


x = 2 + 5
print x