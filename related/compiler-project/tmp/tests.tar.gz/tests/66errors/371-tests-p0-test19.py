#19


t1 = 3
print t1
print 1
t2 = 1
x = t1 + t2
print x