#2


print 1 + 1