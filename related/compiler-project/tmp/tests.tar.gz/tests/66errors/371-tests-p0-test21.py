#21


a = 1 + 1
b = a + 2
c = a + b
d = a + b + c
print d