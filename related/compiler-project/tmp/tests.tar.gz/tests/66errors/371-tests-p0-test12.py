#12


x = ~10
print x