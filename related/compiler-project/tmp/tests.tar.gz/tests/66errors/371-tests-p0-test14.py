#14


x=-7
print x