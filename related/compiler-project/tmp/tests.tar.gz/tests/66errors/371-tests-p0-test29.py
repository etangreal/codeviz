#29
# ERROR: 'f' is an unknown variable.

x = 1 + f
print x
