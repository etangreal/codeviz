#26


a = 3
b = 4
c = 5
print 1
d = 1
print a
print b
print c
print d