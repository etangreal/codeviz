#5


x=10-7
print x