#1


print -1