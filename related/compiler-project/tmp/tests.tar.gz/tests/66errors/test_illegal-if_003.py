a = 5
b = 6
if a == b:
    print "OK"
elif a > b:
