#18


x = 4 / 3
print x