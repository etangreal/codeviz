#24


a = 1 + 1
b = 5 * 2
print b
print 1
b = 1
c = a + b
print c
d = b + a
print d
L = a + b + c + d
print L
s = a + b + c
print s
d = b + a
print d
L = a + b + c - d + L
print L