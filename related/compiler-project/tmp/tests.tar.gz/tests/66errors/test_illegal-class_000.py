class a:
    def __init__():
    def func():
        print "ok"

b = a()
b.func()
