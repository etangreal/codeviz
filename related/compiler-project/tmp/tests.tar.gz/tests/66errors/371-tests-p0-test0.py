#0


print 1