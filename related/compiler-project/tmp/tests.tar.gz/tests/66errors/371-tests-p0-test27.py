#27


print 1
t1 = 1
print t1