#3


x=10
print x