#33


f = 3
x = 1 + f
print x