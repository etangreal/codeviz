#11


x=10-7*2
print x