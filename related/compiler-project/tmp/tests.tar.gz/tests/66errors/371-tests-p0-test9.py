#9


print 1
print 4 - 1