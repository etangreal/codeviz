#8


print 1
x = -1 + 15
print x