#23


a = 1 + 1
b = a + 2
c = a + b
d = a + b + c
x = 3 + 2 * 5
print 1
a = 1
print x + d + a