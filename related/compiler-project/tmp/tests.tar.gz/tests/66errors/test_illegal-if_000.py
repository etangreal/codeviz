a = 1
if a = 3:
    print "Death"
