if False: print(0)
print(1)
