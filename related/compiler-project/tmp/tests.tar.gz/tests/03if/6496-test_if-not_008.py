a=input()
if a:
    if a:
        print (1)
    else:
        print(0)
else:
    print(0)
