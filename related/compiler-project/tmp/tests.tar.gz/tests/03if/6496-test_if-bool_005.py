if False: print(0)
elif True: print (1)
else: print(0)
