if False: print(0)
elif False: print (0)
else: print(1)
