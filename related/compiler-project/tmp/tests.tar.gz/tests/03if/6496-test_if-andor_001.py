a=input()
if a or 0: print(1)
