a=input()
if a==7: print(1)
