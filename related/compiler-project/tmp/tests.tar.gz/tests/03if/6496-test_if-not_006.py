a=input()
if not a: print(0)
elif not a: print (0)
else: print(1)
