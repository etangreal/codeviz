if False: print(0)
else: print (1)
