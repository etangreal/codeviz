a=input()
if a<6: print(0)
elif a>7: print (1)
else: print(0)
