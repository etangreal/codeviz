x = input()
print x
y = input()
print y
if x > y:
    z = x * y - 2
    print z
elif x < y:
    z = -x + (y * 3)
    print z
else:
    z = x + -y
    print z
