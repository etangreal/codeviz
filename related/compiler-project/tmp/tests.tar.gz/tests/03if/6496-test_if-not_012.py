a=input()
if not a:
    print(0)

elif a:
    print( 1)

elif a:
    print( 1)

elif not a:
    print( 0)

else:
    print( 0)
