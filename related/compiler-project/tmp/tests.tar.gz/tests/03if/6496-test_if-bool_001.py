if True: print(1)
