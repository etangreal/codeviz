# Testing the True, False, and, not, if, else
x=input()
y=False
if x==10 and not(y):
    print 10
elif x>10:
    print 100
else:
    print -1
