#23
#if statements| Test fails

if (True):
	print 1
