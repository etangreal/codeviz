if True:
	print "good"

if False:
	print "Not good"

if False:
	print "Not good"
elif True:
	print "good"

if False:
	print "Not good"
elif False:
	print "Not good"

if True:
	print "good"
elif True:
	print "good 2"

if True:
	print "good"
elif False:
	print "Not good"

if False:
	print "Not good"
else:
	print "good"

if True:
	print "good"
else:
	print "Not good"

if True:
	print "good"
elif False:
	print "Not good"
else:
	print "Not good"

if True:
	print "good"
elif True:
	print "good 2"
else:
	print "Not good"

if False:
	print "Not good"
elif True:
	print "good"
else:
	print "Not good 2"
