a=input()
if a>7:
    if a>7:
        if a<6:
            print (0)
        else:
            print (1)
    else:
        print(0)
else:
    print(0)

if a<6:
    print(0)
elif a>7:
    print (1)
else:
    print(0)

