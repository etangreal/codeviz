a=input()
if not a: print(0)
elif a: print (1)
else: print(0)
