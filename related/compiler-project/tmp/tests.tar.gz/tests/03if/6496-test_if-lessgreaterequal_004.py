a=input()
if a<=6: print(0)
else: print (1)
