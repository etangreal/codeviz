a=input()
if a or 0: print(1)
if a and 0: print (0)
if a or 0: print(1)
