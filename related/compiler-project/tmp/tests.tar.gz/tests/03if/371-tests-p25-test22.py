#22
#if statements| Test succeeds

if (True):
	print 1
