bt1 = True
bf1 = False
andt1=bt1 and bt1

if bt1:
    print input()
elif andt1:
    print 0
else:
    print 0

if bf1:
    print 0
elif andt1:
    print input()
else:
    print 0

if bt1:
    print 0
elif andt1:
    print 0
else:
    print input()

