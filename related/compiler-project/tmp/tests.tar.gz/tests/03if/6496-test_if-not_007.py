a=input()
if a: print(1)
if not a: print (0)
if a: print(1)
