a=input()
if a and 0:
    print(0)

elif a or 0:
    print( 1)

elif a or 0:
    print( 1)

elif a and 0:
    print( 0)

else:
    print( 0)
