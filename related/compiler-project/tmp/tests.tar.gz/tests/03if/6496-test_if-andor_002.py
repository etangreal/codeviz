a=input()
if a and 0: print(0)
print(1)
