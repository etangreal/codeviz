a=input()
if a and 0: print(0)
elif a or 0: print (1)
else: print(0)
