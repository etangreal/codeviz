a=input()
if a<6: print(0)
print(1)
