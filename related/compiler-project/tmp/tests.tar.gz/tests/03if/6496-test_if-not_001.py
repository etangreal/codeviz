a=input()
if a: print(1)
