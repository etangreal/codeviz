#29
#if statements, including elif and else clauses | Test fails

if (False):
	print 1
elif(True):
	print 2
else:
	print 3
