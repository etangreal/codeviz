#24
#if statements, including elif | Test succeeds


if (True):
	print 1

elif (False):
	print 2
