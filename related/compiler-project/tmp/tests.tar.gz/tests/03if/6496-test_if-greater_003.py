a=input()
if a>7: print(1)
else: print(0)
