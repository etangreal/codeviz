a=input()
if a:
    if a:
        if not a:
            print (0)
        else:
            print (1)
    else:
        print(0)
else:
    print(0)
