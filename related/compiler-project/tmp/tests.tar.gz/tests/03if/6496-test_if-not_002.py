a=input()
if not a: print(0)
print(1)
