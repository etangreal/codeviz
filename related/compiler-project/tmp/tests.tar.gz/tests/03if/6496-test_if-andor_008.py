a=input()
if a or 0:
    if a or 0:
        print (1)
    else:
        print(0)
else:
    print(0)
