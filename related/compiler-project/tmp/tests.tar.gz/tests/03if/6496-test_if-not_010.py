a=input()
if a:
    if a:
        if not a:
            print (0)
        else:
            print (1)
    else:
        print(0)
else:
    print(0)

if not a:
    print(0)
elif a:
    print (1)
else:
    print(0)

