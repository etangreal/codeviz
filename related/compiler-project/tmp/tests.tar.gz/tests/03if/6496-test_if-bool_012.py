if False:
    print(0)

elif True:
    print( 1)

elif True:
    print( 1)

elif False:
    print( 0)

else:
    print( 0)
