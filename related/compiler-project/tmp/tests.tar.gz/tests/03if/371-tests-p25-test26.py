#26
#if statements, else clauses  | Test succeeds

if (False):
	print 1
else:
	print 2
