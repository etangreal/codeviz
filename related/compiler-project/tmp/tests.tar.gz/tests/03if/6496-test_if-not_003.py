a=input()
if a: print(1)
else: print(0)
