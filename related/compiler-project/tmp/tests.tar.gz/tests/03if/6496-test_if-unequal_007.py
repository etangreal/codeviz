a=input()
if a!=7: print(1)
if a==6: print (0)
if a!=7: print(1)
