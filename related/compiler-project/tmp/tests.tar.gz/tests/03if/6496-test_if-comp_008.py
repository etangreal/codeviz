a=input()
if a==7:
    if a==7:
        print (1)
    else:
        print(0)
else:
    print(0)
