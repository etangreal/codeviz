#25
#if statements, including elif | Test fails 


if (True):
	print 1

elif (False):
	print 2
