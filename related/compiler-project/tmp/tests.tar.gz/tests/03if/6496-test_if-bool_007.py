if True: print(1)
if False: print (0)
if True: print(1)
