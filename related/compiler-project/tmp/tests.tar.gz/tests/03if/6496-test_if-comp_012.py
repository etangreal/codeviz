a=input()
if a==6:
    print(0)

elif a==7:
    print( 1)

elif a==7:
    print( 1)

elif a==6:
    print( 0)

else:
    print( 0)
