#!/usr/bin/env python2.7

x = input()
y = 2
if(x == 5):
    y = 5
else:
    y = 0
print(y)
