#17
#The logical operators 'and' | Test fails

True and True == True