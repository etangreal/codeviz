#0
##The boolean literals True | Test succeeds
True