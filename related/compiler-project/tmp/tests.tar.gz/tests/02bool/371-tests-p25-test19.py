#19
#The logical operators 'or' | Test fails

True or False == True