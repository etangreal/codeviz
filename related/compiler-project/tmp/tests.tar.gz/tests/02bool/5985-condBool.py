## Josafat Piraquive
## Simon Maurer
##
## conditional testcases
##

a = input()
b = input()
c = input()
d = input()
print a == a
print a == b
print not a == a
print not a == b
print a == a and b == b
print a == b and b == b
print not a == b and b == b
print a == b or b == b
print a == b or b == a
print not (a == b and b == a)
print not a == b and b == a
print a != a
print a != b
print a < b
print a > d
print a <= a
print a >= a
print a > a
print b < b
print a and b
print b and a
print a or b
print b or a
print c and a
print a and c
print c or a
print a or c
print not a
print not c
print a == (a or b)
print b == (a or b)
print a == (a and b)
print b == (a and b)
print True and True 	
print False and False
print False and True
print True and False
print False or False
print False or True
print True or False
print True or True
print d or True
print d or False
print d and True
print d and False
print True or d
print False or d
print True and d 
print False and d
print a and b and c and d
print a and b and d
print a or b or c or d
print a or b or d
