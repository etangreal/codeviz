#13
#The comparison operators <= | Test fails

4 <= 6