#10
#The comparison operators > | Test succeeds

5 > 3