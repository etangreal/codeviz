#21
#The logical operators 'not'  | Test fails

not False == True