#12
#The comparison operators <= | Test succeeds

4 <= 6