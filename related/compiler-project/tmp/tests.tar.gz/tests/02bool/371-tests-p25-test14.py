#14
#The comparison operators >= | Test succeeds

3 >= 7