print 2 and 3
print 2 or 3
print 2 & 3
print 2 | 3
print not 1
print not 0
a = input()
b = input()
print a and b
print a or b