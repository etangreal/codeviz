#4
#The comparison operators == | Test succeeds

2==2