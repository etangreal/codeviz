#16
#The logical operators 'and' | Test succeeds

True and True == True