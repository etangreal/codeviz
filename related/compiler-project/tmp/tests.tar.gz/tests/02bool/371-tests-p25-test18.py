#18
#The logical operators 'or' | Test succeeds

True or False == True