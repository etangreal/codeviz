#20
#The logical operators 'not'  | Test succeeds

not False == True