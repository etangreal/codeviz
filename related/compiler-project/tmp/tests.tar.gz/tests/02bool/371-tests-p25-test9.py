#9
#The comparison operators < | Test fails

2 < 3