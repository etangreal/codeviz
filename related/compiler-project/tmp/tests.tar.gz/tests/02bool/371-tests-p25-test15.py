#15
#The comparison operators >= | Test fails

3 >= 7