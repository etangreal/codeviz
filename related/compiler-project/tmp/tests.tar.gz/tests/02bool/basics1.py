n = 1
y = n + 1
x = input()
print x
bt1 = True
bf1 = False
andt1=bt1 and bt1
print bt1 and bt1
print bt1 and bf1
print bf1 or bt1
not bt1
print n==y
print n!=y
print n<=y
print n>=y
print n>y
print n<y
