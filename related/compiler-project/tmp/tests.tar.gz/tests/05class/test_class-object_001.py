class A(object):
    def __init__( self ):
        print 999
a=A()
