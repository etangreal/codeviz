class A(object):
    def __init__( self ):
        pass
    def func( self, val):
        print val

a=A()
a.func( 777 )
