class A(object):
    def __init__( self, val ):
        print val

a=A(777)
