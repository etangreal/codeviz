x = - input()
print x + input()

n0 = 0
n1 = 1
n0 - n1
r0 = n1 - n1
-n1
print r0
print -n1
n1 * 2
n2=2
print n1 * n2
n2/n1
n4 = 4
print 4/n2
print n4/n2
# n1/0
~3
n00=~2+3
bn0 = n00 == n0
print bn0
nn5=~n4
print ~nn5
