#variable overloading
x=True
x=10
print x
